#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <conio.h>
#include <time.h>

using namespace std;
   int wilk1=15, szczur1=20;
  int mieso=10, m_miksturka=25, s_miksturka=50,  d_miksturka=100;
  int c;
int lecz=0, m_m_lecz=0, s_m_lecz=0, d_m_lecz=0;
 int sila;
 char wybor, wybor1, wybor2, wybor3, wybor4, wybor5, wybor6;
 int exp=0;
 int lvl=0;
 int gracz=50;



 int leczenie_d1 (int lecz4)
{

                                         do
                                         {



                                            if(lecz>0)
                                              {
                                                gracz=gracz+d_miksturka;
                                                lecz=lecz-1;
                                                  if(gracz<=50)
                                                {

                                                   cout << "Uleczyles sie twoj stan zdrowia to: "<<gracz<<endl;
                                                   cout << "pozostalo Ci przedmiotow leczacych: "<<lecz<<endl;
                                                }
                                                  else if(gracz>50)
                                                  {
                                                      gracz=gracz-gracz+50;
                                                      cout << "Uleczyles sie twoj stan zdrowia to: "<<gracz<<endl;
                                                      cout << "pozostalo Ci przedmiotow leczacych: "<<lecz<<endl;
                                                  }
                                              }

                                            else cout << "Niemasz sie czym uleczyc " ;
                                              }while((gracz<50) && (lecz>0));



}

 int leczenie_s1 (int lecz3)
 {

                                         do
                                         {



                                            if(lecz>0)
                                              {
                                                gracz=gracz+m_miksturka;
                                                lecz=lecz-1;
                                                  if(gracz<=50)
                                                {

                                                   cout << "Uleczyles sie twoj stan zdrowia to: "<<gracz<<endl;
                                                   cout << "pozostalo Ci przedmiotow leczacych: "<<lecz<<endl;
                                                }
                                                  else if(gracz>50)
                                                  {
                                                      gracz=gracz-gracz+50;
                                                      cout << "Uleczyles sie twoj stan zdrowia to: "<<gracz<<endl;
                                                      cout << "pozostalo Ci przedmiotow leczacych: "<<lecz<<endl;
                                                  }
                                              }

                                            else cout << "Niemasz sie czym uleczyc " ;
                                              }while((gracz<50) && (lecz>0));



 }

 int leczenie_m1 (int lecz2)
 {

                                         do
                                         {


                                            if(lecz>0)
                                              {
                                                gracz=gracz+m_miksturka;
                                                lecz=lecz-1;
                                                  if(gracz<=50)
                                                {

                                                   cout << "Uleczyles sie twoj stan zdrowia to: "<<gracz<<endl;
                                                   cout << "pozostalo Ci przedmiotow leczacych: "<<lecz<<endl;
                                                }
                                                  else if(gracz>50)
                                                  {
                                                      gracz=gracz-gracz+50;
                                                      cout << "Uleczyles sie twoj stan zdrowia to: "<<gracz<<endl;
                                                      cout << "pozostalo Ci przedmiotow leczacych: "<<lecz<<endl;
                                                  }
                                              }

                                            else cout << "Niemasz sie czym uleczyc " ;
                                              }while((gracz<50) && (lecz>0));



 }

 int leczenie (int lecz1)
 {


                                         do
                                         {



                                            if(lecz>0)
                                              {
                                                gracz=gracz+mieso;
                                                lecz=lecz-1;
                                                  if(gracz<=50)
                                                {

                                                   cout << "Uleczyles sie twoj stan zdrowia to: "<<gracz<<endl;
                                                   cout << "pozostalo Ci przedmiotow leczacych: "<<lecz<<endl;
                                                }
                                                  else if(gracz>50)
                                                  {
                                                      gracz=gracz-gracz+50;
                                                      cout << "Uleczyles sie twoj stan zdrowia to: "<<gracz<<endl;
                                                      cout << "pozostalo Ci przedmiotow leczacych: "<<lecz<<endl;
                                                  }
                                              }

                                            else cout << "Niemasz sie czym uleczyc " ;
                                              }while((gracz<50) && (lecz>0));







 }

int wybor_leczenia=0(int lecz5)
 {
 cout << "Czy chcesz sie uzdrowic "<<endl;
                        cout << "1. Tak"<<endl;
                        cout << "2. Nie"<<endl;

                                wybor4=getch();

                                switch (wybor4)
                                {
                                    case '1':
  cout << "Czym chcesz sie uzdrowic?"<<endl;
  cout << "1. Miesem?"<<endl;
  cout << "2. Mala miksturka?"<<endl;
  cout << "3. Srednia miksturka?"<<endl;
  cout << "4. Duza miksturka?"<<endl;
    wybor6=getch();
  switch(wybor6)
{
case '4':
 leczenie_d1(d_miksturka);
break;
  case '3':
 leczenie_s1(s_miksturka);
break;
 case '2':
leczenie_m1(m_miksturka);
break;
 case '1':
leczenie(mieso);
break;

}

}
}
int atak_wilk(int wilk)
{
    cout << "Atakujesz wilka "<<endl;
                         srand(time(NULL));
                          cout<<"Ilosc zyc wilka "<<wilk1<<endl;
                          cout<<"_______________________________"<<endl;

                            do
                            {

                               int  c=(rand() % 3)  + 4;
                                int  d=(rand() % 2)  +2;
                                 cout << "Obrazenia jakie zadales "<<c<<endl;
                                   wilk1=wilk1-c;
                                   gracz=gracz-d;
                                   cout << "Obrazenia jakie otrzymales 4"<<endl;
                                   cout<<"_______________________________"<<endl;
                                   cout << "Pozostalo ci zyc "<<gracz<<endl;
                                     if(wilk1>=0)
                                        {
                                          cout<<"Ilosc zyc wilka "<<wilk1<<endl;
                                          cout<<"_______________________________"<<endl;
                                        }

                                     else;

                            }while (wilk1>0);

                            srand(time(NULL));
                            int  a=(rand() % 3)  + 1;
                               lecz=lecz+a;
                                  cout << "Wilk zostal pokany zdobyles "<< a <<" mieso ktorym mozesz sie uzdrowic doda ci 10 pkt. hp "<<endl;

                                     cout <<"Uzyskales 25 pkt. doswiadczenia"<<endl;
                                      exp=exp+25;
                                       if(exp>250)
                                          {
                                             lvl++;
                                             gracz=gracz+15;
                                             cout << "osiagnales: " <<lvl<<" poziom"<<endl;

                                          }
                                             else;
                                             wilk1=wilk1-wilk1+15;

}
int atak_szczur(int szczur)
{
    cout << "Atakujesz szczura "<<endl;

                        srand(time(NULL));
                          cout<<"Ilosc zyc szczura "<<szczur1<<endl;
                           cout<<"_______________________________"<<endl;
                            do
                            {

                               int  c=(rand() % 3)  + 4;
                                int  d=(rand() % 2)  +2;
                                 cout << "Obrazenia jakie zadales "<<c<<endl;
                                   szczur1=szczur1-c;
                                   gracz=gracz-d;
                                   cout << "Obrazenia jakie otrzymales 4"<<endl;
                                    cout<<"_______________________________"<<endl;
                                   cout << "Pozostalo ci zyc "<<gracz<<endl;
                                     if(szczur1>=0)
                                     {
                                     cout<<"Ilosc zyc szczura: "<<szczur1<<endl;
                                      cout<<"_______________________________"<<endl;
                                     }
                                     else;

                            }while (szczur1>0);
                            srand(time(NULL));
                            int  z=(rand() % 3)  + 1;
                             lecz=lecz+z;
                                 cout << "Sczur zostal pokany zdobyles "<< z <<" sztuk miesa ktorym mozesz sie uzdrowic doda Ci 10 pkt. hp "<<endl;
                                  cout <<"Uzyskales 25 pkt. doswiadczenia"<<endl;
                                      exp=exp+25;
                                       if(exp>250)
                                          {
                                             lvl++;
                                             gracz=gracz+15;
                                             cout << "osiagnales: " <<lvl<<" poziom"<<endl;

                                          }
                                             else;

                                                 szczur1=szczur1-szczur1+20;

}


int main()
{
    for(;;)
{
    cout <<"Menu Glowne"<<endl;
    cout <<"----------------"<<endl;
    cout <<"1. Start"<<endl;
    cout <<"2. Statystyki"<<endl;
    cout <<"3. Autor"<<endl;
     cout <<"4. Koniec programu"<<endl;

      cout << "Wybierz " << endl;
      wybor=getch();

      switch(wybor)
      {
      case '1':


              cout << "Witam nieznajomy gdzie chcesz sie udac? "<<endl;
              cout << "A. W strone ruin? "<<endl;
              cout << "B. W strone pustkowia? "<<endl;
              cout << "C. W strone gor? "<<endl;

              wybor1=getch();

              switch(tolower(wybor1)){


                case 97:
                 cout << "W trakcie podrozy zdobywasz lage "<<endl;
                 cout << "Po drodze do ruin napotykasz wilka "<<endl;
                  cout << "Atakujesz wilka czy udziekasz? "<<endl;
                  cout << "1. Atak"<<endl;
                  cout << "2. Ucieczka"<<endl;
                  cout<<""<<endl;
                 wybor2=getch();
                  switch(wybor2){

                    case '1':
                        atak_wilk(wilk1);


                       wybor_leczenia(lecz);

                        cout <<  "Dotarles do ruin" << endl;
                        break;

                     case '2':
                        cout << "Uciekasz w poplochu xd ";
                        break;



                  }
                  cout << "W ruinach spotykasz wedrowca "<<endl;
                        cout <<"witaj nieznajomy nazywa sie Linster mam dlaciebie zadanie w kryptach tych ruin zgobilem"<<endl;
                        cout<<"swoj magiczny medalion czy mogl bys go dla mnie znalesc"<<endl;
                        cout << "1. Tak, pomoge Ci"<<endl;
                        cout << "2. Niestety nie moge Ci pomuc przyszedlem tu w innej sprawie "<<endl;
                        wybor3=getch();
                        switch(wybor3)
                          case '1':
                           cout << "Udajesz sie do krypty" <<endl;
                           cout << "Zza rogu wyskakuje olbrzymi szczor i Cie atakuje "<<endl;


                           atak_szczur(szczur1);


                            wybor_leczenia(lecz);

                        cout << "Przeszukujesz szczora "<<endl;
                             srand(time(NULL));
                             c=(rand() % 9) + 1;


                        if((c==5) || (c==2) || (c==8) ){
                            cout << "Znalazles przynim amulat " << endl;
                            cout << "1. Mozesz odac amulat nieznajomemu "<<endl;
                            cout << "2. Mozesz zachowac amulet dla siebie "<< endl;
                        }
                        else
                            {
                            cout << "Nic nie udalo mi sie znalesc"<<endl;
                            cout << "1. Czy chcesz kontynuowac poszukiwanie amuletu"<<endl;
                            cout << "2. Udaj sie do ruin starego zamku"<<endl;
                            }
                            wybor4=getch();
                            switch (wybor4)
                            {
                            case '1':
                                cout<<"W trakcie drogi napotykasz kolejnego olbrzymiego szczura"<<endl;
                                atak_szczur(szczur1);


                                wybor_leczenia(lecz);

                                cout << "Wtrakcie drogi napotykasz kufer"<<endl;
                                cout << "Czy chcesz go otworzy�?"<<endl;
                                cout<< "1. Tak"<<endl;
                                cout<< "2. Nie"<<endl;
                                wybor5=getch();
                                switch (wybor5)
                                {
                                case '1':
                                    cout << "W kufrze znalazles zardzewialy miecz male miksurki leczenia "<<endl;
                                    cout << "i poszukiwany przezciebie medalion teraz mozoszesz sie wroci "<<endl;
                                    cout << "i oddac medalion Linsterowi  ";
                                    m_m_lecz=m_m_lecz+2;

                                }

                            }


                break;
                case 98:

                break;
                case 99:

                break;

              }

          break;
      case '2':
              cout<<"Statystyki ";
          break;
      case '3':

              cout << "Bartosz Biskup";
          break;
            break;
      case '4':
            exit(0);
      break;
          default: cout<<"Do zobaczenia";

      }
      getchar();getchar();
      system ("cls");
}
    return 0;

}
