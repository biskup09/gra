#include "E:\\gra\\pliki.h\\zmienne.h"
#include "E:\\gra\\pliki.h\\przeciwnik.h"
#include "E:\\gra\\pliki.h\\leczenie.h"





using namespace std;




  void rysuj_zdjecie2(FILE *kufer)
    {
        char read_string2[200];
        while(fgets(read_string2,sizeof(read_string2),kufer) != NULL)
        printf("%s",read_string2);
    }
    void rysuj_zdjecie(FILE *napis)
    {
        char read_string2[200];
        while(fgets(read_string2,sizeof(read_string2),napis) != NULL)
        printf("%s",read_string2);
    }

void rysuj_zdjecie3(FILE *przejscie)
    {
        char read_string2[200];
        while(fgets(read_string2,sizeof(read_string2),przejscie) != NULL)
        printf("%s",read_string2);
    }


 class Bohater
 {
     public:
  int exp=0;
  int lvl=0;
  int gracz=50;

 };

 class Zapis
 {
     public:
     void zapisz()
     {
         FILE * save = fopen ( "save.sav", "w" );
         fprintf( save, "%01d, %01d, 01d, %01d", & lecz, & m_m_lecz, & s_m_lecz, & d_m_lecz, & exp, &
               lvl, & gracz);
               system ("pause");

               fclose ( save );
     }
     void wczytaj()
      {

       FILE * save = fopen( "save.sav", "r");
       fprintf (save, "01d, %01d, %01d, %01d", & lecz, & m_m_lecz, & s_m_lecz, & d_m_lecz, & exp, &
               lvl, & gracz);
               system ("pause");
                fclose (save);

      }

 };

int main()
{
    for(;;)
{
    srand(time(NULL));
    cout << "................."  << endl;
    cout << "|Menu Glowne    |"  << endl;
    cout << "''''''''''''''''' "  << endl;
    cout << "1. Start"           << endl;
    cout << "2. Statystyki"      << endl;
    cout << "3. Autor"           << endl;
    cout << "4. Koniec programu" << endl;

      cout << "Wybierz " << endl;
      wybor=getch();

      switch(wybor)
      {
      case '1':
          cout << endl;
          {


      /*         string napis = "Witaj nieznajomy zostales wybrany do poszukiwania skradzionego \nartefaktu ktory jest potrzebyny do powstrzmania ndchodzacego zla. \nWezwanego przez kaplna ktory odszedl z klasztoru i odwrocil sie od \nswoich braci. Artefakt zostal podzielony na trzy czesci. \nAby je odnalesc bedziesz musial sie zmierzyc z wieloma niebezpieczenistwami, \npulapkami, zagadkami. Po drodze napotkasz postacie ktore beda mialy \ndla ciebie rozne questy poboczne dzieki ktorym zdobedziesz wiecej \npunktow dosiwiadczenia i dzieki czemu twoje punkty zycia sie zwieksza.\n ";

                           for(int i = 0; i < napis.length(); i++)
                                {
                                    cout << napis[i];
                                    Sleep(10);
                                }
*/
                             cout << endl;

                          cout << "A. W strone ruin? "      <<endl;
                          cout << "B. W strone pustkowia? " <<endl;
                          cout << "C. W strone gor? "       <<endl;

                                  wybor1=getch();

                                  switch(tolower(wybor1)){


                                            case 97:
                                              cout << endl;
                                              cout << "W trakcie podrozy zdobywasz lage "   << endl;
                                              cout << "Po drodze do ruin napotykasz wilka " << endl;
                                              cout << "Atakujesz wilka czy udziekasz? "     << endl;
                                              cout << "1. Atak"                             << endl;
                                              cout << "2. Ucieczka"                         << endl;



                  wybor2=getch();
                  switch(wybor2){

                    case '1':
                        cout << endl;
                       Przeciwnicy p1;
                       p1.wilk();

                       cout << endl;

                        Leczenie z1;
                       z1.wybor_leczenia();


                        cout <<  "Dotarles do ruin" << endl;
                        break;

                     case '2':
                        cout << "Uciekasz w poplochu xd ";
                        break;



                  }
                  cout << "W ruinach spotykasz wedrowca "<<endl;
                        cout <<"witaj nieznajomy nazywa sie Linster mam dlaciebie zadanie w kryptach tych ruin zgobilem"<<endl;
                        cout<<"swoj magiczny medalion czy mogl bys go dla mnie znalesc"<<endl;
                        cout << "1. Tak, pomoge Ci"<<endl;
                        cout << "2. Niestety nie moge Ci pomuc przyszedlem tu w innej sprawie "<<endl;
                        wybor3=getch();
                        switch(wybor3)
                          case '1':
                           cout << endl;
                           cout << "Udajesz sie do krypty" <<endl;
                           cout << "Zza rogu wyskakuje scierwojad i Cie atakuje "<<endl;

                           Sleep(4000);

                           cout << endl;

                          Przeciwnicy p2;
                          p2.scierwojad();
                          cout << endl;

                             Leczenie z1;
                       z1.wybor_leczenia();
                        cout << endl;

                        cout << "Przeszukujesz scierwojada "<<endl;

                             c=(rand() % 9) + 1;


                        if((c==5) || (c==2) || (c==8) ){
                            cout << "Znalazles przynim amulat " << endl;
                            cout << "1. Czy chcesz kontynuowac podrozowanie po krypcie"<<endl;
                            cout << "2. Udaj sie do ruin starego zamku i odaj medalion"<<endl;
                        }
                        else {
                            cout << "Nic nie udalo mi sie znalesc"<<endl;
                            cout << "1. Czy chcesz kontynuowac podrozowanie po krypcie"<<endl;
                            cout << "2. Udaj sie do ruin starego zamku "<<endl;
                                 }

                            wybor4=getch();
                            switch (wybor4)
                            {
                            case '1':
                                cout << endl;
                                cout << "W trakcie drogi napotykasz kolejnego scierwojada"<<endl;

                                Sleep(4000);

                                Przeciwnicy p2;
                                p2.scierwojad();

                                Leczenie z1;
                                z1.wybor_leczenia();


                                cout << "Wtrakcie drogi znajdujesz kufer"<<endl;
                                cout << "Czy chcesz go otworzy�?"<<endl;
                                cout<< "1. Tak"<<endl;
                                cout<< "2. Nie"<<endl;
                                wybor5=getch();
                                switch (wybor5)
                                {
                                case '1':
                                    cout << endl;
                                    char *nazwa_pliku2 = "E:\\gra\\obrazki\\image3.txt";
                                             FILE *kufer = NULL;

                                               if((kufer = fopen(nazwa_pliku2,"r")) == NULL)
                                                   {
                                                    fprintf(stderr,"Niema takiego pliku%s\n",nazwa_pliku2);
                                                    return 1;
                                                   }
                                                rysuj_zdjecie2(kufer);
                                                cout << endl;

                                    if ((c==5) || (c==2) || (c==8))
                                    {
                                     cout << "W kufrze znalazles zardzewialy miecz i dwie miksturki leczenia "<<endl;
                                     cout << "teraz mozoszesz sie wroci i oddac medalion Linsterowi"<<endl;

                                     m_m_lecz=m_m_lecz+2;
                                    }
                                    else
                                        {

                                               cout << "W kufrze znalazles zardzewialy miecz i dwie miksturki leczenia. "<<endl;
                                               cout << "i poszukiwany przez ciebie medalion teraz mozoszesz sie wroci "<<endl;
                                            cout << "i oddac medalion Linsterowi  ";
                                                 m_m_lecz=m_m_lecz+2;
                                        }
                                    break;

                                }
                                Sleep(5000);

                                cout <<"Dalej juz nie moze sie udac wracasz sie do Listera aby my oddac medalion Linsterowi  "<<endl;
                                cout << "Odales medalion i zdobyles 200 pkt doswiadczeniateraz. Teraz mozoesz "<<endl;
                                cout << "isc do ruin starego zamku w poszukiwaniu jednej z czesci zginionego arti oddac medalion Linsterowiefaktu"<<endl;
                                         exp=exp+200;


                                        Sleep(5000);
                                         if(exp>250)
                                          {
                                             lvl++;
                                             gracz=gracz+15;

                                          //         sndPlaySound( "C:\\programowanie\\gra\\muzyka\\level_up.wav", SND_ASYNC );
                                                }

                                                char *nazwa_pliku = "C:\\programowanie\\gra\\obrazki\\image6.txt";
                                                FILE *napis = NULL;

                                                  if((napis = fopen(nazwa_pliku,"r")) == NULL)
                                                   {
                                                    fprintf(stderr,"Niema takiego pliku%s\n",nazwa_pliku);
                                                    return 1;
                                                   }
                                                    rysuj_zdjecie(napis);
                                                    cout << endl;
                                                    cout << endl;

                                             cout << "Osiagnales: " <<lvl<<" poziom"<<endl;

                                            cout << "Jestes przed glownym wejsciu do zamku po wejsciu napotykasz trzy przejscia ktore wybierasz? ";
                                            cout << "1. ";
                                            cout << "2. ";
                                            cout << "3. ";

                                           cout << endl;
                                           char *nazwa_pliku3 = "C:\\programowanie\\gra\\obrazki\\przejscia.txt";
                                                FILE *przejscie = NULL;
                                                 if((przejscie = fopen(nazwa_pliku3,"r")) == NULL)
                                                   {
                                                    fprintf(stderr,"Niema takiego pliku%s\n",nazwa_pliku3);
                                                    return 1;
                                                   }
                                                rysuj_zdjecie3(przejscie);

                                            wybor7=getch();
                                            switch(wybor7)
                                            {
                                                case '1':
                                                    cout << "Wybrales pierwsze przejscie znajdujesz mala miksture leczenia " << m_m_lecz++ << endl;
                                                    cout << "Podnosisz ja i idziesz dalej napotykasz tajemnicza postac podnosi sie i mowi" << endl;
                                                    cout << "Nie potrzebnie tu przychodziles zginieeeeesz!!!!!!!!!!! " << endl;

                                                      Przeciwnicy z;
                                                       z.zjawa();

                                                      Leczenie a;
                                                       a.wybor_leczenia();






                                                break;
                                                case '2':


                                                break;
                                                case '3':



                                                break;
                                            }





                            }


                break;
                case 98:
                 cout<<"mmmm";
                break;
                case 99:

                break;

              }}

          break;
      case '2':
              cout << "Statystyki "                  <<endl;
              cout << "Poziom "               << lvl << endl;
              cout << "Punkty doswiadczenia " << exp << endl;
          break;
      case '3':

              cout << "Bartosz Biskup";
          break;
            break;
      case '4':
            exit(0);
      break;
          default: cout<<"Do zobaczenia";

      }
      getchar();getchar();
      system ("cls");
}
    return 0;

}

