#include <iostream>
#include <windows.h>
#include <stdio.h>
#include <cstdlib>
#include <conio.h>
#include <time.h>
#include <iomanip>
#include <string>



int mieso=10, m_miksturka=25, s_miksturka=50,  d_miksturka=75;
char wybor, wybor1, wybor2, wybor3, wybor4, wybor5, wybor6, wybor7, wybor8, wybor9, wybor10, wybor11, wybor12, wybor13, wybor14, wybor15, wybor16, wybor17, wybor18, wybor19, wybor20, znak, znak1, znak2, znak3, znak4, znak5, znak6;
int wilk_0=15, scierwojad_0=20, zjawa_0=30;
int lecz=0, m_m_lecz=0, s_m_lecz=0, d_m_lecz=0;
int exp=0;
int lvl=0;
int gracz=50;
//char znak2;
int c;
int flaga = 0;
int sila;
