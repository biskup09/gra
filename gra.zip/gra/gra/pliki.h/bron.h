#include <iostream>
#include <windows.h>
#include <stdio.h>
#include <cstdlib>
#include <conio.h>
#include <time.h>
#include <iomanip>
#include <string>
#include "E:\\gra\\pliki.h\\postac.h"
#include "E:\\gra\\pliki.h\\zmienne.h"
class Bron
//:public Hero
{
 public:

 int laga()
 {


    c=(rand() % 3)  + 4;

    c=c+((sila/10)*2);

 }
 int miecz()
 {


     c=(rand() % 7)  + 5;

    c=c+((sila/10)*2);

 }

};
