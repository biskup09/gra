#include <iostream>
#include <windows.h>
#include <stdio.h>
#include <cstdlib>
#include <conio.h>
#include <time.h>
#include <iomanip>
#include <string>
/*class Hero
{

  public:

  int hp = 50;
  int sila = 10;
  int zrecznosc = 10;
  int exp = 0;
  int lvl = 0;
  int gracz = 50;
  int pancerz = 10;
};
*/
