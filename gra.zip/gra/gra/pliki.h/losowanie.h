#include <iostream>
#include <windows.h>
#include <stdio.h>
#include <cstdlib>
#include <conio.h>
#include <time.h>
#include <iomanip>
#include <string>

using namespace std;
class Losowanie
{
    public:

int losowanie( int min, int max )
{
     return( rand() % max ) + min;
}

void tablica()
{
    srand(time(NULL));

int const n(8);
int t[n];
t[0]=1000;
t[1]=1800;
t[2]=2060;
t[3]=3500;
t[4]=1500;
t[5]=2000;
t[6]=4000;
t[7]=3000;
 int d = losowanie( 0, 7 );
    Sleep (t[d]);
    cout << " * " << endl;
}
};
